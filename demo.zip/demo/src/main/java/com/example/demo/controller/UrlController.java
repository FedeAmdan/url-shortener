package com.example.demo.controller;

import com.example.demo.model.UrlData;
import com.example.demo.repository.UrlShortenerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@RestController
@RequestMapping("/")
public class UrlController {

    @Autowired
    private UrlShortenerRepository urlRepository;

    @GetMapping("/{shortUrl}")
    public String findByName(
            @PathVariable(name = "shortUrl") String shortUrl) {
        return urlRepository.findByShortUrl(shortUrl).getUrl();
    }

    @PostMapping("/generate/")
    public String generateShortUrl(
            @RequestBody String url
    ) {
        String shortUrl = generate(url);
        UrlData urlData = new UrlData();
        urlData.setUrl(url);
        urlData.setShortUrl(shortUrl);
        urlData.setCounter(0);
        urlRepository.save(urlData);
        return shortUrl;
    }

    public String generate(String url) {
        return url.substring(0,1);
    }
}

