package com.example.demo.model;

import org.springframework.core.annotation.AliasFor;

import javax.persistence.*;

@Entity
@Table(name = "urlShortener")
public class UrlData {
    /*
      id SERIAL PRIMARY KEY,
  url VARCHAR(50) NOT NULL,
  short VARCHAR(50) NOT NULL,
  counter INTEGER NOT NULL,
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(name = "url", nullable = false)
    private String url;
    @Column(name = "shortUrl", nullable = false)
    private String shortUrl;

    @Column(name = "counter", nullable = false)
    private Integer counter;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getShortUrl() {
        return shortUrl;
    }

    public void setShortUrl(String shortUrl) {
        this.shortUrl = shortUrl;
    }

    public Integer getCounter() {
        return counter;
    }

    public void setCounter(Integer counter) {
        this.counter = counter;
    }
}
